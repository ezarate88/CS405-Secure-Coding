// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

class customException {
};

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception
    // EZ - Added std::exception throw.
  throw std::exception();

  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}
void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;
  try { // Wrapping of the do_even_more custom logic
    if(do_even_more_custom_application_logic())
    {
     std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  
  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main

    //EZ -- Caught the exception here and threw from here. Was unsure how to make code continue regardless of the exception.
  catch (std::exception& ex) {
    std::cout << "Standard Exception " << ex.what() << std::endl;
    throw customException() ;
  }

  std::cout << "Leaving Custom Application Logic." << std::endl;

  

}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception
  if (den == 0) {
    throw std::runtime_error("Unable to divide by Zero."); // EZ -- Runtime errors are pretty normal for mathematical logical errors.
  }

  return (num / den);
}

void do_division() //noexcept  <-- Not sure what this is for.
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  float numerator = 10.0f;
  float denominator = 0;
  try{
  auto result = divide(numerator, denominator);
  std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
    //EZ - Item was thrown from the divide function and the catch is here for the runtime error.
  catch(std::runtime_error& re) {
    std::cout << re.what() << std::endl;
  }
}

int main()
 {
    try{
        std::cout << "Exceptions Tests!" << std::endl;
    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console
        //EZ -- I had a difficult time getting the exceptins to show up in the correct order.
        try {
            do_division();
            do_custom_application_logic();
        }
        catch(customException e) {
            std::cout << "Caught a custom exception!" << std::endl;
            
        }
        throw 1; // EZ - For the end of main exception.
        
    }
    
    catch (int e) {
        if (e == 1) {
            std::cout << "Exception for Main" << std::endl;
        }
    }
    // EZ - Catch all exception branch in case they were unhandled but all were handled. 
    catch( ... ) {
        std::cout << "Uncaught Exception Caught" << std::endl;
    }
    

}



// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
